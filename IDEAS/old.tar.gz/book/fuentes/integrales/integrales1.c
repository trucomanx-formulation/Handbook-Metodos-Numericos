#include <stdio.h>	//por el uso de printf
#include <math.h>	//por el uso de exp

float funcion(float t)
{
	return exp(-t*t);
}

float Integral(float (*func)(float),float a,float b)
{
	float suma=0;
	float x,h=0.001;

	for(x=a;x<b;x=x+h)
	{
		suma=suma+func(x);
	}
	return suma*h;
}

int main(void) 
{
	float I;

	I=Integral(funcion,0.0,10.0);
	printf("El resultado de la integral es : %f\n",I);

	return 0;
}
