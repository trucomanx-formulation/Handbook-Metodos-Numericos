%%
DAT.MARKERSIZE=12;
DAT.FONTSIZE=24;
DAT.LINEWIDTH=3;


MINX=0;
MAXX=10;
N=16;
M=4;

rand("seed", 8.4880e-311);
X=(MAXX-MINX)*rand(N,1)+MINX;
X=sort(X);

randn("seed", 2.1842e+237);
Y=0.01*(X.^2-3^2).*(X.^2-6^2)+2^2+2^2*randn(size(X));

X'
Y'

AX=min(X);  BX=max(X);
%[C RCON]=funcC((X-AX)/(BX-AX),Y,M)
[C RCON]=funcC(X,Y,M)

func_plot_and_print(MINX,MAXX,X,Y,C,DAT,'minimizando_hx_2.eps');
