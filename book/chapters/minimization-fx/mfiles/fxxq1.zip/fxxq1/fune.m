function err=fune(x,y,b,alpha,q)
	if(norm(size(x)-size(y)) ~= 0)
		error('The size of x and y are not equals.');
	endif

	L=numel(x);
	err=zeros(size(x));

	for LL=1:L
		X=[x(LL);y(LL)];
        F=funf(X);
		err(LL)=norm(F-b)^2+alpha*norm(X-q)^2;
	endfor
endfunction
