function b=funf(X)
	x=X(1);
	y=X(2);
	b=[ x^2; 
        y^2;
        (x+y)];

endfunction
