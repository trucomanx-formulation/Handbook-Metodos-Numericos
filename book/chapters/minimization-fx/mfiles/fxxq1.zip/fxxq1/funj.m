function JJ=funj(X)

	JJ=[2*X(1) 0; ...
		0 2*X(2); ...
		1 1];

endfunction
