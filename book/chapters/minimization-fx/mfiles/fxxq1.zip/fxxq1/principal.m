%
MARKERSIZE=12;
FONTSIZE=24;
LINEWIDTH=3;

B=[1;1;2];
alpha=0.1;
Q=[0;0];

tx = ty = linspace (0.0, 2, 25)';
[xx, yy] = meshgrid (tx, ty);
err=fune(xx,yy,B,alpha,Q);
figure(1)
surfc(xx,yy,err)
hz=zlabel('e(x)');
set(hz,'fontsize',FONTSIZE);
hx=xlabel('x_1');
set(hx,'fontsize',FONTSIZE);
hy=ylabel('x_2');
set(hy,'fontsize',FONTSIZE);
zlim([0 max(max(err))])
colormap(jet)
view([-10, 20])%view([0, 0])%
print(gcf,'surfcfx.eps','-depsc',['-F:' num2str(FONTSIZE)])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P=zeros(2,32);

P=[0.1;0.1];
PEND=funde(P(1),P(2),B,alpha,Q)

ERR=fune(P(1,end),P(2,end),B,alpha,Q);
while (ERR(end)>0.001^2)&&(numel(ERR)<10)
	X=P(:,end);
	JJ=funj(X);
	F =funf(X);

	[INVERSA RCOND]=inv(JJ'*JJ+alpha*eye(2));
	if(RCOND==0)
		error(['Not exist inverse matrix to P:[' num2str(X(1)) ',' num2str(X(2)) ']']);
	endif

	P(:,end+1)=X-INVERSA*(JJ'*(F-B)+alpha*(X-Q));
	ERR=[ERR fune(P(1,end),P(2,end),B,alpha,Q)];
endwhile

PEND=funde(P(1,end),P(2,end),B,alpha,Q)
P
ERR
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
D=[linspace(0,2,201);linspace(0,2,201)];
E=fune(D(1,:),D(2,:),B,alpha,Q);
DT=sqrt(D(1,:).^2 + D(2,:).^2);

PT=sqrt(P(1,:).^2 + P(2,:).^2);

figure(2)
plot(DT,E,'linewidth',LINEWIDTH)
hold on
plot(PT,ERR,"-o","markersize", MARKERSIZE,'linewidth',LINEWIDTH)
hx=xlabel('r=||x||');
set(hx,'fontsize',FONTSIZE);
hy=ylabel('e(r)');
set(hy,'fontsize',FONTSIZE);
%hl=legend("X_k");
%set(hl,"fontsize", FONTSIZE);
set(gca, "fontsize", FONTSIZE);
xlim([0 2.0]);
ylim([0 1.25*max(ERR)]);
hold off
print(gcf,'plotfx.eps','-depsc',['-F:' num2str(FONTSIZE)])

