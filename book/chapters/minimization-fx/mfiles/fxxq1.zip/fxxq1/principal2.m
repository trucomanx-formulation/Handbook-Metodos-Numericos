file:///media/fernando/FER16G-BTRFS/LIBROS/FORMULATION/Handbook-Metodos-Numericos/book/chapters/minimization-fx/mfiles/fxxq1/principal2.m

